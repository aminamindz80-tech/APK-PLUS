plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}
android {
    namespace = "com.erpatelier.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.erpatelier.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-hors-ligne"
        // Python embarqué : téléphones 64 bits et 32 bits (retirer une ligne pour alléger l'APK)
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
chaquopy {
    defaultConfig { version = "3.12" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // Lecture de texte sur photo, modèle inclus dans l'APK : fonctionne sans Internet
    implementation("com.google.mlkit:text-recognition:16.0.1")
}

// Le serveur et l'interface de l'ERP sont ceux du dossier parent : copiés ici avant chaque compilation
val syncServeur by tasks.registering(Copy::class) {
    from(File(rootDir.parentFile, "server.py"))
    into(layout.projectDirectory.dir("src/main/python"))
}
val syncInterface by tasks.registering(Copy::class) {
    from(File(rootDir.parentFile, "static"))
    into(layout.projectDirectory.dir("src/main/assets/erp_static"))
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(syncServeur, syncInterface) }
